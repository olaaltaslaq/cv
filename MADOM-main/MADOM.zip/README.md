# MADOM

### Team members
- Ola AlTaslaq
- Dina 
- Mohammed Mosleh
- Mohammed Al-Hanbali
- Ahmad yousef
- Abdallah Hamoury 

## our project
The site is about movies and selling specialized movies, and it will be a great user experience